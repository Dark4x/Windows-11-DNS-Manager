@echo off
net session >nul 2>&1
if %errorLevel% == 0 (
    goto :START_SCRIPT
) else (
    powershell -Command "Start-Process '%~dpnx0' -Verb RunAs"
    exit
)

:START_SCRIPT
cd /d "%~dp0"
setlocal enabledelayedexpansion
chcp 65001 >nul
title Windows-11-DNS-Manager
color 0B

:: Задаем жесткий размер окна: 65 символов в ширину и 25 строк в высоту
mode con: cols=65 lines=25

:MENU
cls
echo.
echo    ██╗    ██╗ ██╗ ██╗     ██████╗ ███╗   ██╗███████╗
echo    ██║    ██║███║███║     ██╔══██╗████╗  ██║██╔════╝
echo    ██║ █╗ ██║╚██║╚██║     ██║  ██║██╔██╗ ██║███████╗
echo    ██║███╗██║ ██║ ██║     ██║  ██║██║╚██╗██║╚════██║
echo    ╚███╔███╔╝ ██║ ██║     ██████╔╝██║ ╚████║███████║
echo     ╚══╝╚══╝  ╚═╝ ╚═╝     ╚═════╝ ╚═╝  ╚═══╝╚══════╝
echo.
echo          [ D N S   M A N A G E R  v1.0 ]
echo    ======================================================
echo.
echo       [ 1 ] Подключить DNS из списка файлов      
echo       [ 2 ] Вернуть в автоматический режим       
echo.
echo       [ 0 ] Выход из программы                   
echo.
echo    ======================================================
echo.
set /p main_choice="     Выберите действие (0-2): "

if "%main_choice%"=="1" goto SELECT_FILE
if "%main_choice%"=="2" goto RESET_DNS
if "%main_choice%"=="0" exit
goto MENU

:SELECT_FILE
cls
echo.
echo    ======================================================
echo                 ДОСТУПНЫЕ КОНФИГУРАЦИИ            
echo    ======================================================
echo.
set count=0
for %%f in (data\*.txt) do (
    set /a count+=1
    set "file!count!=%%f"
    echo        [!count!] %%~nf
)
echo.
echo    ------------------------------------------------------
set /p file_choice="     Выберите номер файла (или 0 для отмены): "

if "%file_choice%"=="0" goto MENU
if not defined file!file_choice! (
    echo.
    echo     [!] Ошибка: Неверный выбор.
    timeout /t 2 >nul
    goto SELECT_FILE
)

set "target_file=!file%file_choice%!"

set i=0
for /f "usebackq delims=" %%a in ("%target_file%") do (
    set /a i+=1
    set "dns!i!=%%a"
)

echo.
echo     [*] Применяю настройки из файла %target_file%...
echo     [ IPv4: %dns1% / %dns2% ]

for /f "tokens=3*" %%i in ('netsh interface show interface ^| findstr /C:"Connected" /C:"Подключено"') do set "interface=%%j"

netsh interface ipv4 set dns name="%interface%" static %dns1% primary >nul
netsh interface ipv4 add dns name="%interface%" %dns2% index=2 >nul

netsh interface ipv6 set dns name="%interface%" static %dns3% primary >nul 2>&1
netsh interface ipv6 add dns name="%interface%" %dns4% index=2 >nul 2>&1

echo.
echo     [+] Успешно! Новые адреса DNS установлены.
echo.
pause
goto MENU

:RESET_DNS
cls
echo.
echo    ======================================================
echo                     СБРОС НАСТРОЕК                 
echo    ======================================================
echo.
echo     [*] Возвращение в автоматический режим (DHCP)...

for /f "tokens=3*" %%i in ('netsh interface show interface ^| findstr /C:"Connected" /C:"Подключено"') do set "interface=%%j"

netsh interface ipv4 set dns name="%interface%" dhcp >nul
netsh interface ipv6 set dns name="%interface%" dhcp >nul 2>&1

echo.
echo     [+] Успешно! Все настройки возвращены в авто-режим.
echo.
pause
goto MENU